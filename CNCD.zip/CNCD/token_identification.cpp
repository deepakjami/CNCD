#include <bits/stdc++.h>
using namespace std;

bool isIvec(string s, vector<string> &a)
{
    for (int i = 0; i < a.size(); i++)
    {
        if (a[i] == s)
            return true;
    }
    return false;
}

bool isNum(string s)
{
    int i = 0;
    while (i < s.length())
    {
        if (!isdigit(s[i]))
        {
            return false;
        }
        i++;
    }
    return !s.empty();
}

int main()
{
    string s;
    cout << "Enter the name of the C file: ";
    cin >> s;

    fstream inputFile(s);
    if (!inputFile.is_open())
    {
        cerr << "Error: File could not be opened!" << endl;
        return 1;
    }

    vector<string> keywords = {
        "auto", "break", "case", "char", "const", "continue", "default", "do",
        "double", "else", "enum", "extern", "float", "for", "goto", "if",
        "inline", "int", "long", "register", "restrict", "return", "short",
        "signed", "sizeof", "static", "struct", "switch", "typedef",
        "union", "unsigned", "void", "volatile", "while", "_Alignas",
        "_Alignof", "_Atomic", "_Bool", "_Complex", "_Generic", "_Imaginary",
        "_Noreturn", "_Static_assert", "_Thread_local"};
    vector<string> operators = {
        "+", "-", "*", "/", "%", "++", "--", "=", "+=", "-=", "*=", "/=", "%=",
        "==", "!=", ">", "<", ">=", "<=", "&&", "||", "!", "&", "|", "^", "~",
        "<<", ">>", ">>=", "<<=", "&=", "|=", "^=", "->", ".", "[]", "()", "?:"};
    vector<string> logical_operators = {
        "&&", "||", "!"};
    vector<string> other_operators = {
        ";", ",", "{", "}", "(", ")", "[", "]", ":", "#", "##", "\\", "?", ".", "->"};

    vector<string> comment, iden, arth_ops, logi_ops, pre, other_ops, constants, keyword;
    string line;

    while (getline(inputFile, line))
    {
        if (line.find("//") == 0)
        {
            comment.push_back(line);
            continue;
        }
        else if (line.find("#") == 0)
        {
            pre.push_back(line);
            continue;
        }
        else
        {
            vector<string> words;
            string current = "";
            for (int i = 0; i <= line.length(); i++)
            {
                if (i == line.length() || isspace(line[i]) || ispunct(line[i]))
                {
                    if (!current.empty())
                    {
                        words.push_back(current);
                        current = "";
                    }
                    if (ispunct(line[i]))
                    {
                        string punct(1, line[i]);
                        words.push_back(punct);
                    }
                }
                else
                {
                    current += line[i];
                }
            }

            for (string &word : words)
            {
                if (isIvec(word, keywords))
                {
                    keyword.push_back(word);
                }
                else if (isIvec(word, operators))
                {
                    arth_ops.push_back(word);
                }
                else if (isIvec(word, logical_operators))
                {
                    logi_ops.push_back(word);
                }
                else if (isIvec(word, other_operators))
                {
                    other_ops.push_back(word);
                }
                else if (isNum(word))
                {
                    constants.push_back(word);
                }
                else
                {
                    iden.push_back(word);
                }
            }
        }
    }
    inputFile.close();

    auto printVector = [](string title, vector<string> &v)
    {
        cout << title << ":\n";
        for (const auto &item : v)
            cout << item << endl;
    };

    printVector("Keywords", keyword);
    printVector("Identifiers", iden);
    printVector("Arithmetic Operators", arth_ops);
    printVector("Logical Operators", logi_ops);
    printVector("Other Operators", other_ops);
    printVector("Comments", comment);
    printVector("Preprocessor Directives", pre);

    return 0;
}
