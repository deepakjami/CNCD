l = []
def bitStuffing(s):
    idx,cnt,f = 0,0,0
    while idx < len(s):
        if s[idx] == '1':
            cnt += 1
            if cnt == 5 :
                s = s[:idx+1] + '0' + s[idx+1:]
                f += 1
                idx += 1
                cnt = 0
        else :
            cnt = 0
        idx += 1
    l.append(f)
    s = '01111110'+ s + '01111110'
    return s

def bit_deStuffing(p):
    p = p[8:-8]
    idx,cnt = 0,0
    while idx < len(p):
        if p[idx] == '1':
            cnt += 1
            if cnt == 5 :
                p = p[:idx+1] + p[idx+2:]
                cnt = 0
        else :
            cnt = 0
        idx += 1
    return p

s = input("Enter the text :") #Input String
s1 = "" # Binary String
for i in range(len(s)):
    s1 += f'{ord(s[i]):08b}' # Convert Into Binary
frameSize = int(input("Enter the frame size :"))
if len(s1) % frameSize != 0:
    s1 += ('0' * (frameSize - len(s1) % frameSize))  # Check How many xtra bits to add to the last frame
nFrames = len(s1) // frameSize # Count no of frames

stuffed_data = "" 
i = 0
while i < len(s1):
    frame = s1[i:i+frameSize] #Divide the frames according to frame size
    print("Original Frame :",frame)
    stuffed_frame = bitStuffing(frame)
    print("After Bit Stuffing :",stuffed_frame)
    stuffed_data += stuffed_frame
    i += frameSize

frameSize += 16 #Add xtra 16 bits to frame size
frame_Size = frameSize # Temp frame size

destuffed_data = ""
i,j = 0,0
while j < nFrames:
    if l[j] < 0:
        frameSize += l[j]
    else :
        frameSize = frame_Size
    j += 1
    frame = stuffed_data[i:i+frameSize]
    destuffed_frame = bit_deStuffing(frame)
    destuffed_data += destuffed_frame
    i += frameSize

res = ""
idx = 0
while idx < len(destuffed_data):
    byte = destuffed_data[idx:idx+8]
    if len(byte) == 8:
        res += chr(int(byte,2))
    idx += 8

print("Receiver Side :")
print("Received Stuffed Data :",stuffed_data)
print("After Bit Stuffing : ",destuffed_data)
print("Text Converted : ",res)